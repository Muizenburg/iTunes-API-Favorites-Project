let assert = require("chai").assert;
let handleStateChange = require('../src/components/books').handleStateChange;


describe("Status and content", function () {


    it("status", function () {
      let result = handleStateChange();
     assert.typeOf(result,'string')
       
      });
    });



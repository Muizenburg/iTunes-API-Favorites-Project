import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Dropdown from "react-bootstrap/Dropdown";

function SearchBar(props) {
  return (
    <div>
      <Dropdown>
        <Dropdown.Toggle variant="success" id="dropdown-basic">
          Choose Media Type to add
        </Dropdown.Toggle>

        <Dropdown.Menu>
          <Dropdown.Item href="/music">Music</Dropdown.Item>
          <Dropdown.Item href="/books">Books</Dropdown.Item>
        </Dropdown.Menu>
      </Dropdown>
    </div>
  );
}

export default SearchBar;

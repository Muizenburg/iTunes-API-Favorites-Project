import React, { Component } from "react";
import "isomorphic-fetch";
import { InputGroup, FormControl, Button, Table, Form } from "react-bootstrap";

class Books extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      weather: null,
      search: "",

      searchResults: [],
      index: "",
      artist: "",
      trackName: "",
      mediaType: "",

      show: false,

      test: [],
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmitSearch = this.handleSubmitSearch.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleStateChange = this.handleStateChange.bind(this);
  }

  showModal = () => {
    this.setState({ show: true });
  };

  hideModal = () => {
    this.setState({ show: false });
  };

  handleChange(event) {
    const searchBook = event.target.value;
    const urlSearch =
      "https://itunes.apple.com/search?term=" +
      searchBook +
      "&limit=5&media=ebook";
    this.setState({
      search: urlSearch,
    });
    console.log(urlSearch);
  }

  async handleSubmitSearch(event) {
    const url = this.state.search;
    const response = await fetch(url);
    const data = await response.json();
    console.log(data.results);
    this.setState({
      searchResults: data.results,
      loading: false,
    });
  }

  handleStateChange = (event) => {
    const searchResultz = this.state.searchResults;

    const idselected = event.target.getAttribute("name");
    const selectedArtist = searchResultz[idselected].artistName;
    const selectedTrackName = searchResultz[idselected].trackName;
    const selectedMediaType = searchResultz[idselected].kind;
    alert(
      "Book has been selected - click save button to store in your favorites"
    );

    console.log(idselected);
    console.log(selectedTrackName);

    this.setState({
      artist: selectedArtist,
      trackName: selectedTrackName,
      mediaType: selectedMediaType,
    });

    console.log(this.state.artist);
    console.log(this.state.trackName);
    console.log(this.state.mediaType);
  };

  handleSubmit(e) {
    console.log(this.state.webprojects);
    alert("Your media item has been saved successfully!");
    fetch("/api", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        artist: this.state.artist,
        trackName: this.state.trackName,
        mediaType: this.state.mediaType,
      }),
    })
      .then((res) => res.json())
      .catch((error) => console.log("Error:", error));
  }

  render() {
    let searchResult = this.state.searchResults;
    console.log(searchResult);

    const ebooks = searchResult.map((ebook, index) => {
      return (
        <tr key={ebook.trackId} onClick={this.handleStateChange}>
          <td name={index}>{index + 1}</td>
          <td name={index}>{ebook.artistName}</td>
          <td name={index}>{ebook.trackName}</td>
          <td name={index}>{ebook.kind}</td>
          <td name={index}>Click to add</td>
        </tr>
      );
    });

    return (
      <div>
        <h3> eBooks: </h3>
        <InputGroup className="mb-3">
          <InputGroup.Prepend>
            <InputGroup.Text id="basic-addon1">
              Search for Books
            </InputGroup.Text>
          </InputGroup.Prepend>
          <FormControl
            onChange={this.handleChange}
            placeholder="e.g Stephen King"
            aria-label="Username"
            aria-describedby="basic-addon1"
          />
          <Button
            variant="primary"
            type="submit"
            onClick={this.handleSubmitSearch}
          >
            Search
          </Button>
        </InputGroup>

        <div>{this.state.searchResultsArtistName}</div>
        <div>{this.state.searchResultsTrackName}</div>
        <div>{this.state.searchResultskind}</div>

        <Table striped bordered hover>
          <thead>
            <tr>
              <th>#</th>
              <th>Author</th>
              <th>Book Title</th>
              <th>Media type</th>
              <th>Add to collection?</th>
            </tr>
          </thead>
          <tbody>{ebooks}</tbody>
        </Table>

        <Form onSubmit={this.handleSubmit}>
          <Form.Group>
            <Form.Label>Author</Form.Label>
            <Form.Control
              type="text"
              name="artist"
              onChange={this.handleChange}
              placeholder="--"
              size="lg"
              className="formControl"
              value={this.state.artist}
            />
          </Form.Group>
          <Form.Group>
            <Form.Label>Book Title</Form.Label>
            <Form.Control
              type="text"
              name="trackName"
              onChange={this.handleChange}
              placeholder="--"
              size="lg"
              className="formControl"
              value={this.state.trackName}
            />
          </Form.Group>
          <Form.Group>
            <Form.Label>Media type</Form.Label>
            <Form.Control
              type="text"
              name="mediaType"
              onChange={this.handleChange}
              placeholder="--"
              size="lg"
              className="formControl"
              value={this.state.mediaType}
            />
          </Form.Group>
          <Button variant="primary" type="submit">
            Save in Favs
          </Button>
        </Form>
      </div>
    );
  }
}

export default Books;

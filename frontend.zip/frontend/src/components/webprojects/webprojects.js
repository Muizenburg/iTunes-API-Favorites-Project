import React from "react";
import "./webprojects.css";
import TableCustom from "./tableCustom.js";


class Webprojects extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
    };

  }

  render() {
    return (
      <div>
        <br></br>
        <h1>Favorites</h1>
        <TableCustom />
      </div>
    );
  }
}

export default Webprojects;

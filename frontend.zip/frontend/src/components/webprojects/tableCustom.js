import React from "react";
import Table from "react-bootstrap/Table";
import Button from "react-bootstrap/Button";


class TableCustom extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      webprojects: [],
      title: "",
      description: "",
      website: "",

      show: false,

      updatedWebID: "",
      updatedWebTitle: "",
      updatedWebDescription: "",
      updatedWebWebsite: "",
    };

    this.deleteWeb = this.deleteWeb.bind(this);
  }

  showModal = () => {
    this.setState({ show: true });
  };

  hideModal = () => {
    this.setState({ show: false });
  };

  componentDidMount() {
    fetch("/api")
      .then((res) => res.json())
      .then((webprojects) => this.setState({ webprojects }));
  }


  deleteWeb(id) {
    if (window.confirm("Are you sure?")) {
      fetch("/api/" + id, {
        method: "DELETE",
        header: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      });
    }
  }

  render() {
    let webprojectsMap = this.state.webprojects;

    const projects = webprojectsMap.map((webproject) => {
      let { id, artist, trackName, mediaType } = webproject;

      return (
        <tr key={id} onSubmit={this.handleSubmitDelete}>
          <td>{id}</td>
          <td>{artist}</td>
          <td>{trackName}</td>
          <td>{mediaType}</td>
          <td>

              <Button onClick={() => this.deleteWeb(id)} variant="danger">
                Delete
              </Button>

          </td>
        </tr>
      );
    });

    return (
      <div>
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>#</th>
              <th>Artist/Author</th>
              <th>Track name / Book Title</th>
              <th>Media type</th>
              <th></th>
            </tr>
          </thead>
          <tbody>{projects}</tbody>
        </Table>
      </div>
    );
  }
}

export default TableCustom;

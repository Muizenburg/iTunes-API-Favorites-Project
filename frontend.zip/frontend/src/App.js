import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Webprojects from './components/webprojects/webprojects.js'
import "isomorphic-fetch";
import Music from "./components/music";
import Books from "./components/books";
import SearchBar from "./components/searchBar.js";
import { BrowserRouter, Route } from "react-router-dom";



function App() {
  return (
    <div className="App">
      <h1>Personal Media Library</h1>
      <BrowserRouter>
          <div className="App">
            <SearchBar />
            <Route path="/music" component={Music} />
            <Route path="/books" component={Books} />
          </div>
        </BrowserRouter>

      <Webprojects />
    </div>
  );
}

export default App;
